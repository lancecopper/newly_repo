echo 123456 | sudo -S ls
chmod +x nvr.out
chmod +x watchdognvr.sh
echo 123456 | sudo apt -y install libmysqlclient-dev
echo 123456 | sudo apt -y install libmp4v2-dev


