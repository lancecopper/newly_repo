sudo cp -rf  lib* /usr/lib/x86_64-linux-gnu
chmod +x vgsagent